var http = require('http');
var fs = require("fs");
var qs = require('querystring');
var nodemailer = require('nodemailer');
var MongoClient = require('mongodb').MongoClient;


var dbUrl = "mongodb://localhost:32768/";

http.createServer(function(request, response) {

	if(request.url === "/"){
		console.log("Requested URL is url" +request.url);
		sendFileContent(response, "index.html", "text/html");
	}
	else if(request.url === "/home"){
		console.log("Requested URL is url" +request.url);
		sendFileContent(response, "mymusic.html", "text/html");
	}
	
	else if(request.url === "/music"){
		console.log("Requested URL is url" +request.url);
		sendFileContent(response, "music.html", "text/html");
	}
	else if(request.url === "/logout"){
		console.log("Requested URL is url" +request.url);
		sendFileContent(response, "logout.html", "text/html");
	}
	else if(request.url === "/check_fav"){
		console.log("Requested URL is url" +request.url);
		if(request.method==="POST"){
			formData = '';
			return request.on('data', function(data) {
				formData+=data;
				console.log(formData);
				data= qs.parse(formData);
				var query={"loginid": data["loginid"]};
				return request.on('end', function() {
				MongoClient.connect(dbUrl, function(err, db) {
					if (err) throw err;
						var dbo = db.db("musicdb");
						dbo.collection("fav_list").find(query).sort({_id:-1}).toArray(function(err, result) {
							if (err) throw err;
							db.close();
							return response.end(JSON.stringify(result));
				
						});
				});
			});
			});
		}else{
				console.log("check Fav not POST");
				console.log("Requested URL is url" +request.url);
				formData = '';
				
				MongoClient.connect(dbUrl, function(err, db) {
					if (err) throw err;
					var dbo = db.db("musicdb");
					dbo.collection("fav_list").find({}).sort({_id:-1}).toArray(function(err, result) {
						if (err) throw err;
						db.close();

						return response.end(JSON.stringify(result));
				
					});
				});
			}		
		
	}
	else if(request.url === "/mymusic"){
		console.log("Requested URL is url" +request.url);
		if (request.method === "POST") {
			formData = '';
			msg = '';
			return request.on('data', function(data) {
				console.log("check fav");
				console.log(data);
				formData += data;
				data= qs.parse(formData);
				return request.on('end', function() {
					
					MongoClient.connect(dbUrl, function(err, db) {
						
						
						if (err) throw err;
						var dbo = db.db("musicdb");
						var temphtml = "";
						var query={loginid:data["login"]};
						console.log(query+"@@@@@@@@@@");
						dbo.collection("fav_list").find(query).toArray(function(err, result) {
							if (err) throw err;
							for (var i=0;i<result.length;i++){
								console.log("start loop");
								temphtml+="<div class='w3-third w3-margin-bottom'>";
								temphtml+="<ul class='w3-ul w3-border w3-white w3-center w3-opacity w3-hover-opacity-off'>";
								temphtml+="<li class='w3-black w3-xlarge w3-padding-32'>"+result[i].musicid+"</li>";
								temphtml+="<li class='w3-padding-10'><img src='"+result[i].musicid+"'></li>";
								temphtml+="<li class='w3-padding-10'>trackId:"+result[i].musicid+"</li>";
								temphtml+="<li class='w3-padding-16'>"+result[i].musicid+"</li>";
								temphtml+="<li class='w3-padding-16'><audio controls><source src='"+result[i].musicid+"'></audio></li>";
								temphtml+="<li class='w3-light-grey w3-padding-24'>";
								temphtml+="<button class='w3-button w3-teal w3-padding-large w3-hover-black' onclick=addfav('"+result[i].musicid+"')>Remove Favrate</button>";
								temphtml+="</li>";
								temphtml+="</ul>";
								temphtml+="</div>";
							}
							db.close();
							return response.end(JSON.stringify(result));
							
						});

						
					});
				});
			});	
		}else{
				console.log("ff");
				sendFileContent(response, "mymusic.html", "text/html");
		}
	}
	else if(request.url === "/login"){
		console.log("-->login");
		formData = '';
		console.log("Requested URL is url" +request.url);
		if (request.method === "POST") {
			return request.on('data', function(data) {
				console.log("POST OK");
				formData += data;
				console.log(formData);
				return request.on('end', function() {
					var user;
					user = qs.parse(formData);
					msg = JSON.stringify(user);
					stringMsg = JSON.parse(msg);
					MongoClient.connect(dbUrl, function(err, db) {
						
						
						if (err) throw err;
						var dbo = db.db("musicdb");
						console.log(stringMsg);
						dbo.collection("customers").find(stringMsg).toArray(function(err, result) {
							if (err) throw err;
							console.log(result);
							if(result!=""){
								console.log("login ok");
								loginstatus="1";
							}else{
								console.log("No record");
								loginstatus="0";
							}
							db.close();
						
						
							if(loginstatus==="1"){
								response.end("login_ok");
							}else{
								response.end("login_fail");
							}
							
							
							
						});

						
					});
				});
			});
			
		}else{
				sendFileContent(response, "login.html", "text/html");
			}
	}
    else if(request.url==="/reg"){
        console.log("Requested URL is url" +request.url+"*****");     
        if (request.method === "POST") {
            console.log("Create Account");
			formData = '';
			msg = '';
			return request.on('data', function(data) {
				formData += data;
		
				return request.on('end', function() {
					var user;

					user = qs.parse(formData);
					msg = JSON.stringify(user);
					stringMsg = JSON.parse(msg);
					MongoClient.connect(dbUrl, function(err, db) {
						if (err) throw err;
							var dbo = db.db("musicdb");
							var myobj = stringMsg;
							console.log(stringMsg);
							dbo.collection("customers").insertOne(myobj, function(err, res) {
								if (err) throw err;
								console.log("1 document inserted");
								response.end("Account created!!");
								
								var transporter = nodemailer.createTransport({
									service: 'gmail',
									auth: {
										user: 'nick17_hk@yahoo.com.hk',
										pass: '12345'
									}
								});

								var mailOptions = {
									from: 'nick17_hk@yahoo.com.hk',
									to: 'nick17_hk@yahoo.com.hk',
									subject: 'Welcome to nick music store',
									html: "Welcome"
								};

								transporter.sendMail(mailOptions, function(error, info){
								if (error) {
									console.log(error);
								} else {
									console.log('Email sent');
								}
								
								
								
								
								});
								response.end("Mail sent");
								
								db.close();
							});
						});
			
				});

			}); 
		} else {
			sendFileContent(response, "reg.html", "text/html");
		}
	}
    else if(request.url==="/addtofav"){
        console.log("Requested URL is url" +request.url+"*****");     
        if (request.method === "POST") {
			formData = '';
			msg = '';
			return request.on('data', function(data) {
				formData += data;
				console.log(formData);
		  
				return request.on('end', function() {
					var user;
					var data;
					MongoClient.connect(dbUrl, function(err, db) {
						if (err) throw err;
							var dbo = db.db("musicdb");
							var myobj
							data= qs.parse(formData);
							console.log(data);
							msg = JSON.stringify(data);
							stringMsg = JSON.parse(msg);
							console.log(stringMsg);
							dbo.collection("fav_list").insertOne(stringMsg, function(err, res) {
								if (err) throw err;
								console.log("added 1 record");
								db.close();
							});
							response.end("Added to Fav!!");
						});
			
				});

			}); 
		} else {
			sendFileContent(response, "book.html", "text/html");
		}
	}
	else if(request.url==="/removefav"){
		console.log("Requested URL is url" +request.url);
		if (request.method === "POST") {
			return request.on('data', function(data) {
				formData = '';
				formData += data;
				return request.on('end', function() {
					var user;
					var data;
					MongoClient.connect(dbUrl, function(err, db) {
						if (err) throw err;
						var dbo = db.db("musicdb");
						data= qs.parse(formData);
						
						musicid=data["musicid"];
						console.log(data["loginid"]);
						var query={musicid :musicid,loginid:data["loginid"]};
						dbo.collection("fav_list").deleteOne(query,function(err, result) {
							if (err) throw err;
								console.log("Deleted 1 record");
							db.close();
								response.end("Deleted 1 record");							
						});
					});
				}); 
			}); 
		}else {
			console.log("my_fav.html");
			sendFileContent(response, "my_fav.html", "text/html");
		}
	}
	else if(request.url==="/changepw"){
		console.log("Requested URL is url" +request.url);
		if (request.method === "POST") {
			return request.on('data', function(data) {
				formData = '';
				formData += data;
				return request.on('end', function() {
					var user;
					var data;
					MongoClient.connect(dbUrl, function(err, db) {
						if (err) throw err;
						var dbo = db.db("musicdb");
						data= qs.parse(formData);
						
						console.log(data["loginid"]);
						console.log(data["password"]);
						var query={login:data["loginid"]};
						var newvalues ={$set:{password:data["password"]}};
						dbo.collection("customers").updateOne(query,newvalues,function(err, result) {
							if (err) throw err;
								console.log(result.result.nModified+"Password Update!!");
							db.close();
							
							response.end("Password Updated.");	
						
						});
					});
				}); 
			}); 
		}else {
			console.log("changepw.html");
			sendFileContent(response, "changepw.html", "text/html");
		}
	}
	else if(/^\/[a-zA-Z0-9\/-/]*.js$/.test(request.url.toString())){
		sendFileContent(response, request.url.toString().substring(1), "text/javascript");
	}else if(/^\/[a-zA-Z0-9\/-/]*.bundle.min.js$/.test(request.url.toString())){
		sendFileContent(response, request.url.toString().substring(1), "text/javascript");
	}else if(/^\/[a-zA-Z0-9\/-/]*.css$/.test(request.url.toString())){
		sendFileContent(response, request.url.toString().substring(1), "text/css");
	}else if(/^\/[a-zA-Z0-9\/-]*.min.css$/.test(request.url.toString())){
		sendFileContent(response, request.url.toString().substring(1), "text/css");
	}else if(/^\/[a-zA-Z0-9\/-]*.jpg$/.test(request.url.toString())){
		sendFileContent(response, request.url.toString().substring(1), "image/jpg");
	}else if(/^\/[a-zA-Z0-9-._\/]*.min.js$/.test(request.url.toString())){
		sendFileContent(response, request.url.toString().substring(1), "text/javascript");
	}else if(/^\/[a-zA-Z0-9-]*.min.css.map$/.test(request.url.toString())){
		sendFileContent(response, request.url.toString().substring(1), "text/map");
	}else if(/^\/[a-zA-Z0-9\/-/]*.min.js.map$/.test(request.url.toString())){
		sendFileContent(response, request.url.toString().substring(1), "text/map");
	}else if(/^\/[a-zA-Z0-9\/-/]*.css.map$/.test(request.url.toString())){
		sendFileContent(response, request.url.toString().substring(1), "text/map");
	}else if(/^\/[a-zA-Z0-9\/-/]*.png$/.test(request.url.toString())){
		sendFileContent(response, request.url.toString().substring(1), "image/png");
	}else if(/^\/[a-zA-Z0-9\/-/]*.ico$/.test(request.url.toString())){
		sendFileContent(response, request.url.toString().substring(1), "text/ico");
	}else if(/^\/[a-zA-Z0-9\/-/?]*.ttf$/.test(request.url.toString())){
		sendFileContent(response, request.url.toString().substring(1), "text/font");
	}else if(/^\/[a-zA-Z0-9\/-/?]*.woff$/.test(request.url.toString())){
		sendFileContent(response, request.url.toString().substring(1), "text/woff");
	}else if(/^\/[a-zA-Z0-9\/-/?]*.woff2$/.test(request.url.toString())){
		sendFileContent(response, request.url.toString().substring(1), "text/woff2");
	}else{
		console.log("Requested URL is: " + request.url);
		response.end();
	}
}).listen(10001)

function sendFileContent(response, fileName, contentType){
	fs.readFile(fileName, function(err, data){
		if(err){
			response.writeHead(404);
			response.write("Not Found!");
		}
		else{
			response.writeHead(200, {'Content-Type': contentType});
			response.write(data);
		}
		response.end();
	});
}